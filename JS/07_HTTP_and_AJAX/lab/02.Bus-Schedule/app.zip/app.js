function solve() {

    const stopsUrl = 'http://localhost:3030/jsonstore/bus/schedule';
    let displayElement = document.getElementById('info');
    let departBtnElement = document.getElementById('depart');
    let arriveBtnElement = document.getElementById('arrive');
    let currentStop = 'depot';

    function depart() {
         
         departBtnElement.disabled = true;
         arriveBtnElement.disabled = false;

         fetch(`${stopsUrl}/${currentStop}`)
         .then(response => response.json())
         .then(data => {
            displayElement.textContent = `Next stop ${data.name}`;
            currentStop = data.next;
         })
         .catch(error => {
            departBtnElement.disabled = true;
            arriveBtnElement.disabled = true;

            displayElement.textContent = 'Error';
         })
    }

    async function arrive() {
        departBtnElement.disabled = false;
        arriveBtnElement.disabled = true;

        try {
            const response = await fetch(`${stopsUrl}/${currentStop}`);
            const data = await response.json();
            displayElement.textContent = `Arriving at ${data.name}`;
            currentStop = data.next;
            
        } catch (error) {
            departBtnElement.disabled = true;
            arriveBtnElement.disabled = true;

            displayElement.textContent = 'Error';
        }

        
        
    }

    return {
        depart,
        arrive
    };
}

let result = solve();